from fastapi import APIRouter, Depends, HTTPException

from app.data.db import get_db
from app.security.api_key import require_admin

from app.schemas.usuario import UsuarioUpdate
from app.schemas.especie import Especie as EspecieSchema, EspecieActualizar
from app.schemas.foto import FotoSchema

router = APIRouter(
    prefix="/admin",
    tags=["Admin"]
)

# =========================
# ADMIN USUARIOS
# =========================

@router.get("/usuarios")
def obtener_usuarios(
    db = Depends(get_db),
    admin = Depends(require_admin)
):
    cursor = db.cursor()
    cursor.execute("SELECT * FROM Usuarios")
    usuarios = cursor.fetchall()
    return usuarios


@router.put("/usuarios/{id}")
def actualizar_usuario(
    id: int,
    datos: UsuarioUpdate,
    db = Depends(get_db),
    admin = Depends(require_admin)
):
    cursor = db.cursor()

    cursor.execute(
        "SELECT * FROM Usuarios WHERE id = %s",
        (id,)
    )

    usuario = cursor.fetchone()

    if not usuario:
        raise HTTPException(404, "Usuario no encontrado")

    if datos.nombre:
        cursor.execute(
            "UPDATE Usuarios SET nombre=%s WHERE id=%s",
            (datos.nombre, id)
        )

    if datos.correo:
        cursor.execute(
            "UPDATE Usuarios SET correo=%s WHERE id=%s",
            (datos.correo, id)
        )

    if datos.rol:
        cursor.execute(
            "UPDATE Usuarios SET rol=%s WHERE id=%s",
            (datos.rol, id)
        )

    return {"mensaje": "Usuario actualizado"}


@router.delete("/usuarios/{id}")
def eliminar_usuario(
    id: int,
    db = Depends(get_db),
    admin = Depends(require_admin)
):
    cursor = db.cursor()

    cursor.execute(
        "SELECT * FROM Usuarios WHERE id=%s",
        (id,)
    )

    usuario = cursor.fetchone()

    if not usuario:
        raise HTTPException(404, "Usuario no encontrado")

    cursor.execute(
        "DELETE FROM Usuarios WHERE id=%s",
        (id,)
    )

    return {"mensaje": "Usuario eliminado"}


# =========================
# ADMIN ESPECIES
# =========================

@router.post("/especies")
def crear_especie(
    datos: EspecieSchema,
    db = Depends(get_db),
    admin = Depends(require_admin)
):
    cursor = db.cursor()

    cursor.execute(
        """
        INSERT INTO Especies (nombre, descripcion, tipo)
        VALUES (%s, %s, %s)
        """,
        (
            datos.nombre,
            datos.descripcion,
            datos.tipo
        )
    )

    return {"mensaje": "Especie creada"}


@router.get("/especies")
def obtener_especies(
    db = Depends(get_db),
    admin = Depends(require_admin)
):
    cursor = db.cursor()
    cursor.execute("SELECT * FROM Especies")
    especies = cursor.fetchall()
    return especies


@router.put("/especies/{id}")
def actualizar_especie(
    id: int,
    datos: EspecieActualizar,
    db = Depends(get_db),
    admin = Depends(require_admin)
):
    cursor = db.cursor()

    cursor.execute(
        "SELECT * FROM Especies WHERE ID=%s",
        (id,)
    )

    especie = cursor.fetchone()

    if not especie:
        raise HTTPException(404, "Especie no encontrada")

    if datos.nombre:
        cursor.execute(
            "UPDATE Especies SET nombre=%s WHERE ID=%s",
            (datos.nombre, id)
        )

    if datos.descripcion:
        cursor.execute(
            "UPDATE Especies SET descripcion=%s WHERE ID=%s",
            (datos.descripcion, id)
        )

    if datos.tipo:
        cursor.execute(
            "UPDATE Especies SET tipo=%s WHERE ID=%s",
            (datos.tipo, id)
        )

    return {"mensaje": "Especie actualizada"}


@router.delete("/especies/{id}")
def eliminar_especie(
    id: int,
    db = Depends(get_db),
    admin = Depends(require_admin)
):
    cursor = db.cursor()

    cursor.execute(
        "SELECT * FROM Especies WHERE ID=%s",
        (id,)
    )

    especie = cursor.fetchone()

    if not especie:
        raise HTTPException(404, "Especie no encontrada")

    cursor.execute(
        "DELETE FROM Especies WHERE ID=%s",
        (id,)
    )

    return {"mensaje": "Especie eliminada"}


# =========================
# ADMIN FOTOGRAFIAS
# =========================

@router.post("/fotografias")
def agregar_foto(
    datos: FotoSchema,
    db = Depends(get_db),
    admin = Depends(require_admin)
):
    cursor = db.cursor()

    cursor.execute(
        """
        INSERT INTO Fotografias (especie_id, url)
        VALUES (%s, %s)
        """,
        (
            datos.especie_id,
            datos.url
        )
    )

    return {"mensaje": "Foto agregada"}


@router.delete("/fotografias/{id}")
def eliminar_foto(
    id: int,
    db = Depends(get_db),
    admin = Depends(require_admin)
):
    cursor = db.cursor()

    cursor.execute(
        "SELECT * FROM Fotografias WHERE ID=%s",
        (id,)
    )

    foto = cursor.fetchone()

    if not foto:
        raise HTTPException(404, "Foto no encontrada")

    cursor.execute(
        "DELETE FROM Fotografias WHERE ID=%s",
        (id,)
    )

    return {"mensaje": "Foto eliminada"}


# =========================
# ADMIN COMENTARIOS
# =========================

@router.get("/comentarios")
def obtener_comentarios(
    db = Depends(get_db),
    admin = Depends(require_admin)
):
    cursor = db.cursor()

    cursor.execute("SELECT * FROM Comentarios")

    comentarios = cursor.fetchall()

    return comentarios


@router.delete("/comentarios/{id}")
def eliminar_comentario(
    id: int,
    db = Depends(get_db),
    admin = Depends(require_admin)
):
    cursor = db.cursor()

    cursor.execute(
        "SELECT * FROM Comentarios WHERE ID=%s",
        (id,)
    )

    comentario = cursor.fetchone()

    if not comentario:
        raise HTTPException(404, "Comentario no encontrado")

    cursor.execute(
        "DELETE FROM Comentarios WHERE ID=%s",
        (id,)
    )

    return {"mensaje": "Comentario eliminado"}